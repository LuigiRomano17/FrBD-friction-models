function [Fx,Fy,Mz,zx_full,zy_full,iter,fx_full,fy_full] = ...
    FrBD_solver_GM(sigma_x,sigma_y,params)

%% Unpack parameters

phi_gamma = params.phi_gamma; 
phi       = params.phi; 
phi_psi   = params.phi_psi;

sigma0x = params.sigma_0x; 
sigma0y = params.sigma_0y;

sigmaix = params.sigma_ix(:); 
sigmaiy = params.sigma_iy(:);
tau_i   = params.tau_i(:);
nGM     = numel(tau_i);

a = params.a; b = params.b;
v_S = params.v_S; delta_S = params.delta_S;
mu_s = params.mu_s; mu_d = params.mu_d;
Fz = params.Fz; Vr = params.Vr;

nx = params.nx; ny = params.ny;
domainType = params.domainType; n_p = params.n_p;

maxIter = 10;
tolF = 1e-6;


%% Grid & mask

x_vec = linspace(-a,a,nx);
y_vec = linspace(-b,b,ny);
[XX,YY] = meshgrid(x_vec,y_vec);
dx = x_vec(2)-x_vec(1); 
dy = y_vec(2)-y_vec(1);
Ny = ny; Nx = nx;

switch lower(domainType)
    case 'ellipse'
        mask = (XX/a).^2 + (YY/b).^2 <= 1;
    case 'rectangle'
        mask = (XX/a).^n_p + (YY/b).^n_p <= 1;
end

linIdxFull = reshape(1:Ny*Nx,Ny,Nx);
idx = find(mask);
N = numel(idx);
pos = zeros(Ny,Nx); pos(idx)=1:N;
[rowInd,colInd] = ind2sub([Ny,Nx],idx);


%% Advection field

% Transport velocity (m/s)
U = -1 + phi_gamma*YY; % x-component (m/s)
V = -phi_gamma*XX;     % y-component (m/s)
Uc = U(idx); Vc = V(idx);


%% Neighbours

left_full  = zeros(N,1); right_full = zeros(N,1);
up_full    = zeros(N,1); down_full  = zeros(N,1);

for k = 1:N
    r = rowInd(k); c = colInd(k);
    if c>1,  left_full(k)=linIdxFull(r,c-1); end
    if c<Nx, right_full(k)=linIdxFull(r,c+1); end
    if r>1,  up_full(k)=linIdxFull(r-1,c); end
    if r<Ny, down_full(k)=linIdxFull(r+1,c); end
end

left_pos  = zeros(N,1); right_pos = zeros(N,1);
up_pos    = zeros(N,1); down_pos  = zeros(N,1);

valid = left_full>0;  left_pos(valid)=pos(left_full(valid));
valid = right_full>0; right_pos(valid)=pos(right_full(valid));
valid = up_full>0;    up_pos(valid)=pos(up_full(valid));
valid = down_full>0;  down_pos(valid)=pos(down_full(valid));


%% Initial guess

zx = zeros(N,1); zy = zeros(N,1);
fxi = zeros(N,nGM); fyi = zeros(N,nGM);

Fx_old=0; Fy_old=0; Mz_old=0;


%% Main iteration
for iter = 1:maxIter

    % Rigid relative velocity (m/s)
    % vr updated using previous z
    eps_v = 1e-12;                            % Regularization parameter                      (m^2/s^2)
    vrx = sigma_x - phi*YY(idx) - phi_psi*zy; % Linear rigid relative velocity in x-direction (m/s)
    vry = sigma_y + phi*XX(idx) + phi_psi*zx; % Linear rigid relative velocity in y-direction (m/s)
    vnorm = sqrt(vrx.^2+vry.^2+eps_v);        % Total rigid relative velocity                 (m/s)

    mu_x = (mu_d + (mu_s - mu_d).*exp(-(Vr*vnorm/v_S).^delta_S)); % Longitudinal friction coefficient (-)
    mu_y = (mu_d + (mu_s - mu_d).*exp(-(Vr*vnorm/v_S).^delta_S)); % Lateral friction coefficient (-)

    Mv = sqrt((mu_x.*vrx).^2+(mu_y.*vry).^2+1e-12);
    gamma = Mv./(mu_x.^2 + eps_v);


    %% Build sparse system

    % unknown ordering:
    % [ zx | zy | fx1..fxn | fy1..fyn ]
    nTot = 2*N*(1+nGM);
    rhs = zeros(nTot,1);

    maxEntries = 20*nTot;
    Ii=zeros(maxEntries,1);
    Jj=zeros(maxEntries,1);
    Ss=zeros(maxEntries,1);
    ptr=0;

    idx_zx = @(k) k;
    idx_zy = @(k) N+k;
    idx_fx = @(i,k) 2*N + (i-1)*N + k;
    idx_fy = @(i,k) 2*N + nGM*N + (i-1)*N + k;

    for k = 1:N
        uk = Uc(k); vk = Vc(k);

        %% ---------------- zx equation ----------------
        r = idx_zx(k);

        % transport x
        if uk>=0
            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=r; Ss(ptr)= uk/dx;
            if left_pos(k)>0
                ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_zx(left_pos(k)); Ss(ptr)=-uk/dx;
            end
        else
            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=r; Ss(ptr)=-uk/dx;
            if right_pos(k)>0
                ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_zx(right_pos(k)); Ss(ptr)= uk/dx;
            end
        end

        % transport y
        if vk>=0
            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=r; Ss(ptr)= vk/dy;
            if up_pos(k)>0
                ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_zx(up_pos(k)); Ss(ptr)=-vk/dy;
            end
        else
            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=r; Ss(ptr)=-vk/dy;
            if down_pos(k)>0
                ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_zx(down_pos(k)); Ss(ptr)= vk/dy;
            end
        end

        ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=r; Ss(ptr)=gamma(k)*sigma0x;
        for i=1:nGM
            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_fx(i,k); Ss(ptr)=gamma(k);
        end
        rhs(r)=vrx(k);

        %% ---------------- zy equation ----------------
        r = idx_zy(k);

        % transport x
        if uk>=0
            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=r; Ss(ptr)= uk/dx;
            if left_pos(k)>0
                ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_zy(left_pos(k)); Ss(ptr)=-uk/dx;
            end
        else
            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=r; Ss(ptr)=-uk/dx;
            if right_pos(k)>0
                ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_zy(right_pos(k)); Ss(ptr)= uk/dx;
            end
        end

        % transport y
        if vk>=0
            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=r; Ss(ptr)= vk/dy;
            if up_pos(k)>0
                ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_zy(up_pos(k)); Ss(ptr)=-vk/dy;
            end
        else
            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=r; Ss(ptr)=-vk/dy;
            if down_pos(k)>0
                ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_zy(down_pos(k)); Ss(ptr)= vk/dy;
            end
        end

        ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=r; Ss(ptr)=gamma(k)*sigma0y;
        for i=1:nGM
            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_fy(i,k); Ss(ptr)=gamma(k);
        end
        rhs(r)=vry(k);

        %% ---------------- fx_i equations ----------------
        for i=1:nGM
            r = idx_fx(i,k);

            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=r;
            Ss(ptr)=abs(uk)/dx+abs(vk)/dy + 1/(tau_i(i)*Vr);

            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_zx(k);
            Ss(ptr)=gamma(k)*sigma0x*sigmaix(i);

            for j=1:nGM
                ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_fx(j,k);
                Ss(ptr)=gamma(k)*sigmaix(i);
            end

            rhs(r)=sigmaix(i)*vrx(k);
        end

        %% ---------------- fy_i equations ----------------
        for i=1:nGM
            r = idx_fy(i,k);

            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=r;
            Ss(ptr)=abs(uk)/dx+abs(vk)/dy + 1/(tau_i(i)*Vr);

            ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_zy(k);
            Ss(ptr)=gamma(k)*sigma0y*sigmaiy(i);

            for j=1:nGM
                ptr=ptr+1; Ii(ptr)=r; Jj(ptr)=idx_fy(j,k);
                Ss(ptr)=gamma(k)*sigmaiy(i);
            end

            rhs(r)=sigmaiy(i)*vry(k);
        end
    end

    A = sparse(Ii(1:ptr),Jj(1:ptr),Ss(1:ptr),nTot,nTot);

    %% Identify inflow boundary nodes and enforce Dirichlet=0

    for k=1:N
        if (Uc(k)>=0 && left_full(k)==0) || (Uc(k)<0 && right_full(k)==0) || ...
           (Vc(k)>=0 && up_full(k)==0)   || (Vc(k)<0 && down_full(k)==0)

            rows = [idx_zx(k); idx_zy(k)];
            for i=1:nGM
                rows = [rows; idx_fx(i,k); idx_fy(i,k)];
            end

            for r = rows'
                A(r,:)=0; A(r,r)=1; rhs(r)=0;
            end
        end
    end

    %% Solve linear system

    sol = A\rhs;
    zx = sol(1:N);
    zy = sol(N+1:2*N);
    for i=1:nGM
        fxi(:,i)=sol(idx_fx(i,1):idx_fx(i,N));
        fyi(:,i)=sol(idx_fy(i,1):idx_fy(i,N));
    end

    %% Compute forces & moment

    zx_full=zeros(Ny,Nx); zy_full=zx_full;
    zx_full(idx)=zx; zy_full(idx)=zy;

    fx_full=zeros(Ny,Nx); fy_full=fx_full;
    fx_full(idx)=sigma0x*zx + sum(fxi,2);
    fy_full(idx)=sigma0y*zy + sum(fyi,2);

    switch lower(domainType)
        case 'ellipse'
            p=2*Fz/(pi*a*b)*(1-(XX/a).^2-(YY/b).^2);
        case 'rectangle'
            % p=Fz/(4*a*b*beta(1/n_p,(2*n_p+1)/n_p))*(n_p+1)* ...
            %   (1-(XX/a).^n_p-(YY/b).^n_p);
            p = Fz/(4*a*b) + 0*(1-(XX/a).^n_p-(YY/b).^n_p);
    end
    p(~mask)=0;

    Fx=sum(sum(p.*fx_full))*dx*dy;
    Fy=sum(sum(p.*fy_full))*dx*dy;
    Mz=sum(sum((-fx_full.*(YY+zy_full)+fy_full.*(XX+zx_full)).*p))*dx*dy;

    rel=norm([Fx-Fx_old;Fy-Fy_old;Mz-Mz_old]) / ...
        max(1e-12,norm([Fx_old;Fy_old;Mz_old]));
    if rel<tolF, break; end
    Fx_old=Fx; Fy_old=Fy; Mz_old=Mz;
end
end

