clear; close all; clc;
set(0,'defaultTextInterpreter','latex');


%% Description

% This code implements the semilinear rolling contact model described [1].
% Please cite [1] when using this code for research, industrial, or
% educational purposes.

% References
% [1] Romano, L. Two-dimensional FrBD friction models for rolling contact.
% Nonlinear Dyn 114, 444 (2026). 
% https://doi.org/10.1007/s11071-026-12298-x


%% Model parameters

% Spin slips and kinematic parameters
phi_gamma = 0.00;          % Camber spin   (1/m)
phi_psi = 0.00;            % Turn spin     (1/m)
phi = phi_gamma + phi_psi; % Total spin    (1/m)
Vr = 16;                   % Rolling speed (m/s)

% Stiffnesses and dampings
sigma_0x = 240.0; % Longitudinal stiffness (1/m)
sigma_0y = 240.0; % Lateral stiffness      (1/m)
sigma_1x = 0.00;  % Longitudinal damping   (s/m)
sigma_1y = 0.00;  % Lateral damping        (s/m)

% Contact patch parameters
a = 0.075; % Contact patch semilength (m)
b = 0.05;  % Contact patch semiwidth  (m)
Fz = 500; % Vertical force           (N)
n_p = 20;  % Shape parameter          (-)

% Friction parameters
v_S = 3.49;     % Stribeck velocity               (m/s)
delta_S = 0.60; % Stribeck exponent               (-)
mu_s = 1.00;    % Static friction coefficient     (-)
mu_d = 0.70;    % Dynamic friction coefficient    (-)
theta_x = 1.00; % Longitudinal friction parameter (-)
theta_y = 1.00; % Lateral friction parameter      (-)

% Discretization parameters
nx = 50; % Grid points in x-direction (-)
ny = 50; % Grid points in y-direction (-)

% Parameter vector
params.phi_gamma = phi_gamma; params.phi_psi = phi_psi;
params.phi = params.phi_gamma + params.phi_psi;
params.sigma_0x = sigma_0x; params.sigma_0y = sigma_0y;
params.sigma_1x = sigma_1x; params.sigma_1y = sigma_1y;
params.a = a; params.b = b; params.v_S = v_S; params.delta_S = delta_S;
params.mu_s = mu_s; params.mu_d = mu_d; params.Vr = Vr;
params.theta_x = theta_x; params.theta_y = theta_y; params.Fz = Fz; 
params.nx = nx; params.ny = ny; params.n_p = n_p;
% params.domainType= 'rectangle';
params.domainType= 'ellipse';

% Translational slips
% sigma_x_vals = linspace(-1,1,300); % Longitudinal slip           (-)
% sigma_y_vals = [0.01 0.02 0.04 0.08 0.16]; % Lateral slip for small spin (-)
% sigma_y_vals = linspace(0,0.16,5); % Lateral slip for small spin (-)
% sigma_y_vals = linspace(0,0.24,5); % Lateral slip for large spin (-)

sigma_y_vals = linspace(-1,1,300); % Lateral slip                      (-)
sigma_x_vals = linspace(0,0.16,5); % Longitudinal slip for small spin (-)
% sigma_x_vals = linspace(0,0.24,5); % Longitudinal slip for large spin (-)


%% Tangential forces and vertical moment (Fx,Fy,Mz) 
tic
% Preallocate forces and moment
Fx_vec = zeros(length(sigma_y_vals), length(sigma_x_vals));
Fy_vec = zeros(length(sigma_y_vals), length(sigma_x_vals));
Mz_vec = zeros(length(sigma_y_vals), length(sigma_x_vals));

for i = 1:length(sigma_x_vals)
    for j = 1:length(sigma_y_vals)

        sigma_x = sigma_x_vals(i);
        sigma_y = sigma_y_vals(j);
        fprintf('Solving for sigma_x = %.2f, sigma_y = %.2f...\n', sigma_x, sigma_y);

        [Fx,Fy,Mz] = FrBD_solver_KV(sigma_x,sigma_y,params);

        Fx_vec(j,i) = Fx;
        Fy_vec(j,i) = Fy;
        Mz_vec(j,i) = Mz;

    end
end

toc
%% Figures

% Fx and Fy versus sigma_y
figure
% plot(sigma_y_vals,Fx_vec(:,1), 'Color', [0.00,0.45,0.74], 'LineWidth', 1)
% hold on
% plot(sigma_y_vals,Fx_vec(:,2), 'Color', [0.85,0.33,0.10], 'LineWidth', 1)
% hold on
% plot(sigma_y_vals,Fx_vec(:,3), 'Color', [0.93,0.69,0.13], 'LineWidth', 1)
% hold on
% plot(sigma_y_vals,Fx_vec(:,4), 'Color', [0.49,0.18,0.56], 'LineWidth', 1)
% hold on
% plot(sigma_y_vals,Fx_vec(:,5), 'Color', [0.47,0.67,0.19], 'LineWidth', 1)
% hold on
plot(sigma_y_vals,Fy_vec(:,1), 'Color', [0.00,0.45,0.74], 'LineWidth', 1)
hold on
plot(sigma_y_vals,Fy_vec(:,2), 'Color', [0.85,0.33,0.10], 'LineWidth', 1)
hold on
plot(sigma_y_vals,Fy_vec(:,3), 'Color', [0.93,0.69,0.13], 'LineWidth', 1)
hold on
plot(sigma_y_vals,Fy_vec(:,4), 'Color', [0.49,0.18,0.56], 'LineWidth', 1)
hold on
plot(sigma_y_vals,Fy_vec(:,5), 'Color', [0.47,0.67,0.19], 'LineWidth', 1)
xticks([-0.3 -0.2 -0.1 0 0.1 0.2 0.3])
xticklabels({'$-0.3$','$-0.2$', '$-0.1$','0', '0.1','0.2','0.3'})
yticks([-4000 -3000 -2000 -1000 0 1000 2000 3000 4000])
yticklabels({'$-4$', '$-3$','$-2$','$-1$','0','1','2','3', '4'})
xlabel('Lateral slip $\sigma_y$ (-)')
% ylabel('Tangential forces $F_x, F_y$ (kN)')
ylabel('Lateral force $F_y$ (kN)')
grid off
legend('$\sigma_x = 0$', '$\sigma_x = 0.04$', '$\sigma_x = 0.08$', ...
    '$\sigma_x = 0.12$', '$\sigma_x = 0.16$', 'interpreter', 'latex', ...
    'Location','southeast')
set(gca,'TickLabelInterpreter','latex', 'box', 'off', 'color', 'none',...
'XAxisLocation', 'origin','YAxisLocation', 'origin','layer', 'top')
set(gca,'TickLabelInterpreter','latex')
axis([-0.4 0.4 -1.3*mu_d*Fz 1.3*mu_d*Fz])

% Mz versus sigma_y
figure
plot(sigma_y_vals,Mz_vec(:,1), 'Color', [0.00,0.45,0.74], 'LineWidth', 1)
hold on
plot(sigma_y_vals,Mz_vec(:,2), 'Color', [0.85,0.33,0.10], 'LineWidth', 1)
hold on
plot(sigma_y_vals,Mz_vec(:,3), 'Color', [0.93,0.69,0.13], 'LineWidth', 1)
hold on
plot(sigma_y_vals,Mz_vec(:,4), 'Color', [0.49,0.18,0.56], 'LineWidth', 1)
hold on
plot(sigma_y_vals,Mz_vec(:,5), 'Color', [0.47,0.67,0.19], 'LineWidth', 1)
xticks([-0.3 -0.2 -0.1 0 0.1 0.2 0.3])
xticklabels({'$-0.3$','$-0.2$', '$-0.1$','0', '0.1','0.2','0.3'})
yticks([-20 -10 0 10 20])
yticklabels({'$-20$','$-10$','0','10','20'})
xlabel('Lateral slip $\sigma_y$ (-)')
ylabel('Vertical moment $M_z$ ($\mathrm{N}\,\mathrm{m}$)')
grid off
legend('$\sigma_x = 0$', '$\sigma_x = 0.04$', '$\sigma_x = 0.08$', ...
    '$\sigma_x = 0.12$', '$\sigma_x = 0.16$', 'interpreter', 'latex', ...
    'Location','southeast')
% set(gca,'TickLabelInterpreter','latex', 'box', 'on', 'color', 'none',...
% 'XAxisLocation', 'origin','YAxisLocation', 'origin','layer', 'top')
set(gca,'TickLabelInterpreter','latex', 'box', 'off', 'color', 'none',...
'XAxisLocation', 'origin','YAxisLocation', 'origin','layer', 'top')
axis([-0.4 0.4 1.1*min(min(Mz_vec)) 1.1*max(max(Mz_vec))])

% Fy versus Fx (friction ellipse)
figure
plot(Fx_vec(1,:),Fy_vec(1,:), 'Color', [0.00,0.45,0.74], 'LineWidth', 1)
hold on
plot(Fx_vec(2,:),Fy_vec(2,:), 'Color', [0.85,0.33,0.10], 'LineWidth', 1)
hold on
plot(Fx_vec(3,:),Fy_vec(3,:), 'Color', [0.93,0.69,0.13], 'LineWidth', 1)
hold on
plot(Fx_vec(4,:),Fy_vec(4,:), 'Color', [0.49,0.18,0.56], 'LineWidth', 1)
hold on
plot(Fx_vec(5,:),Fy_vec(5,:), 'Color', [0.47,0.67,0.19], 'LineWidth', 1)
xticks([-4000 -3000 -2000 -1000 0 1000 2000 3000 4000])
xticklabels({'$-4$', '$-3$','$-2$','$-1$','0','1','2','3', '4'})
yticks([-4000 -3000 -2000 -1000 0 1000 2000 3000 4000])
yticklabels({'$-4$', '$-3$','$-2$','$-1$','0','1','2','3', '4'})
xlabel('Longitudinal force $F_x$ (kN)')
ylabel('Lateral force $F_y$ (kN)')
grid off
% legend('$\sigma_y = 0.01$', '$\sigma_y = 0.02$', ...
%     '$\sigma_y = 0.04$', '$\sigma_y = 0.08$', ...
%     '$\sigma_y = 0.16$', 'interpreter', 'latex', ...
%     'Location','southeast')
legend('$\sigma_y = 0$', '$\sigma_y = 0.06$', ...
    '$\sigma_y = 0.12$', '$\sigma_y = 0.18$', ...
    '$\sigma_y = 0.24$','interpreter', 'latex', ...
    'Location','northwest')
set(gca,'TickLabelInterpreter','latex', 'box', 'off', 'color', 'none',...
'XAxisLocation', 'origin','YAxisLocation', 'origin','layer', 'top')
set(gca,'TickLabelInterpreter','latex')
axis equal
axis([1.1*min(min(Fx_vec)) 1.1*max(max(Fx_vec)) 0 1.1*max(max(Fy_vec))])

% Mz versus sigma_x
figure
plot(sigma_x_vals,Mz_vec(1,:), 'Color', [0.00,0.45,0.74], 'LineWidth', 1)
hold on
plot(sigma_x_vals,Mz_vec(2,:), 'Color', [0.85,0.33,0.10], 'LineWidth', 1)
hold on
plot(sigma_x_vals,Mz_vec(3,:), 'Color', [0.93,0.69,0.13], 'LineWidth', 1)
hold on
plot(sigma_x_vals,Mz_vec(4,:), 'Color', [0.49,0.18,0.56], 'LineWidth', 1)
hold on
plot(sigma_x_vals,Mz_vec(5,:), 'Color', [0.47,0.67,0.19], 'LineWidth', 1)
xticks([-0.3 -0.2 -0.1 0 0.1 0.2 0.3])
xticklabels({'$-0.3$','$-0.2$', '$-0.1$','0', '0.1','0.2','0.3'})
yticks([-20 -10 0 10 20])
yticklabels({'$-20$','$-10$','0','10','20'})
xlabel('Longitudinal slip $\sigma_x$ (-)')
ylabel('Vertical moment $M_z$ ($\mathrm{N}\,\mathrm{m}$)')
grid off
% legend('$\sigma_y = 0.01$', '$\sigma_y = 0.02$', ...
%     '$\sigma_y = 0.04$', '$\sigma_y = 0.08$', ...
%     '$\sigma_y = 0.16$', 'interpreter', 'latex', ...
%     'Location','southeast')
legend('$\sigma_y = 0$', '$\sigma_y = 0.06$', ...
    '$\sigma_y = 0.12$', '$\sigma_y = 0.18$', ...
    '$\sigma_y = 0.24$', 'interpreter', 'latex', ...
    'Location','southeast')
set(gca,'TickLabelInterpreter','latex', 'box', 'off', 'color', 'none',...
'XAxisLocation', 'origin','YAxisLocation', 'origin','layer', 'top')
axis([-0.4 0.4 1.1*min(min(Mz_vec)) 1.1*max(max(Mz_vec))])


