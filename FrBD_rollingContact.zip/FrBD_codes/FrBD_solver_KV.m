function [Fx, Fy, Mz, zx_full, zy_full, iter] = ...
    FrBD_solver_KV(sigma_x, sigma_y, params)

%% Unpack parameters

phi_gamma = params.phi_gamma; phi = params.phi; phi_psi = params.phi_psi;
sigma_0x = params.sigma_0x; sigma_0y = params.sigma_0y;
sigma_1x = params.sigma_1x; sigma_1y = params.sigma_1y;
a = params.a; b = params.b; v_S = params.v_S; delta_S = params.delta_S;
mu_s = params.mu_s; mu_d = params.mu_d; 
theta_x = params.theta_x; theta_y = params.theta_y;
Fz = params.Fz; Vr = params.Vr; nx = params.nx; ny = params.ny;
domainType = params.domainType; n_p = params.n_p;

maxIter = 10;
tolF = 1e-6;


%% Grid & mask

x_vec = linspace(-a,a,nx);
y_vec = linspace(-b,b,ny);
[XX,YY] = meshgrid(x_vec,y_vec);
dx = x_vec(2)-x_vec(1); dy = y_vec(2)-y_vec(1);
Ny = ny; Nx = nx;

switch lower(domainType)
    case 'ellipse'
        mask = (XX/a).^2 + (YY/b).^2 <= 1;
    case 'rectangle'
        mask = (XX/a).^n_p + (YY/b).^n_p <= 1;
    otherwise
        error('Unknown domain type');
end

linIdxFull = reshape(1:Ny*Nx, Ny, Nx);
idx = find(mask);
N = numel(idx);
pos = zeros(Ny,Nx); pos(idx) = 1:N;


%% Advection field

% Transport velocity (m/s)
U = -1 + phi_gamma*YY; % x-component (m/s)
V = -phi_gamma*XX;     % y-component (m/s)
Uc = U(idx); Vc = V(idx);


%% Initial guess

zx = zeros(N,1);
zy = zeros(N,1);

Fx_old = 0; Fy_old = 0; Mz_old = 0;


%% Main iteration
for iter = 1:maxIter

    % Rigid relative velocity (m/s)
    % vr updated using previous z
    eps_v = 1e-12;                            % Regularization parameter                      (m^2/s^2)
    vrx = sigma_x - phi*YY(idx) - phi_psi*zy; % Linear rigid relative velocity in x-direction (m/s)
    vry = sigma_y + phi*XX(idx) + phi_psi*zx; % Linear rigid relative velocity in y-direction (m/s)
    v_norm = sqrt(vrx.^2 + vry.^2 + eps_v);   % Total rigid relative velocity                 (m/s)

    % Friction functions
    mu_x = (mu_d + (mu_s - mu_d).* exp(-(Vr*v_norm/v_S).^delta_S))/theta_x; % Longitudinal friction coefficient (-)
    mu_y = (mu_d + (mu_s - mu_d).* exp(-(Vr*v_norm/v_S).^delta_S))/theta_y; % Lateral friction coefficient (-)

    Mv_norm = sqrt((mu_x.*Vr.*vrx).^2 + (mu_y.*Vr.*vry).^2 + eps_v);

    gx = sigma_1x*Mv_norm + mu_x.^2;  % Function gx (-)
    gy = sigma_1y*Mv_norm + mu_y.^2;  % Function gy (-)
    gx(gx < 1e-12) = 1e-12;
    gy(gy < 1e-12) = 1e-12;

    alpha_x = sigma_0x.*(Mv_norm./gx)/Vr;
    alpha_y = sigma_0y.*(Mv_norm./gy)/Vr;
    mu_over_gx = mu_x.^2./gx;
    mu_over_gy = mu_y.^2./gy;


    %% Build sparse system

    [rowInd, colInd] = ind2sub([Ny, Nx], idx);
    left_full  = zeros(N,1); right_full = zeros(N,1);
    up_full    = zeros(N,1); down_full  = zeros(N,1);

    for k = 1:N
        r = rowInd(k); c = colInd(k);
        if c > 1, left_full(k)  = linIdxFull(r, c-1); end
        if c < Nx, right_full(k) = linIdxFull(r, c+1); end
        if r > 1, up_full(k)    = linIdxFull(r-1, c); end
        if r < Ny, down_full(k) = linIdxFull(r+1, c); end
    end

    left_pos  = zeros(N,1); right_pos = zeros(N,1);
    up_pos    = zeros(N,1); down_pos  = zeros(N,1);
    valid = left_full > 0;  left_pos(valid)  = pos(left_full(valid));
    valid = right_full > 0; right_pos(valid) = pos(right_full(valid));
    valid = up_full > 0;    up_pos(valid)    = pos(up_full(valid));
    valid = down_full > 0;  down_pos(valid)  = pos(down_full(valid));

    maxEntries = 10 * N;
    Ii = zeros(maxEntries,1); Jj = zeros(maxEntries,1); Ss = zeros(maxEntries,1);
    ptr = 0;
    rhs = zeros(2*N,1);

    for k = 1:N
        r1 = k; r2 = N + k;
        uk = Uc(k); vk = Vc(k);

        % -------- zx row --------
        if uk >= 0
            ptr = ptr + 1; Ii(ptr)=r1; Jj(ptr)=r1; Ss(ptr)=uk/dx;
            if left_pos(k)>0, ptr=ptr+1; Ii(ptr)=r1; Jj(ptr)=left_pos(k); Ss(ptr)=-uk/dx; end
        else
            ptr = ptr + 1; Ii(ptr)=r1; Jj(ptr)=r1; Ss(ptr)=-uk/dx;
            if right_pos(k)>0, ptr=ptr+1; Ii(ptr)=r1; Jj(ptr)=right_pos(k); Ss(ptr)=uk/dx; end
        end

        if vk >= 0
            ptr = ptr + 1; Ii(ptr)=r1; Jj(ptr)=r1; Ss(ptr)=vk/dy;
            if up_pos(k)>0, ptr=ptr+1; Ii(ptr)=r1; Jj(ptr)=up_pos(k); Ss(ptr)=-vk/dy; end
        else
            ptr = ptr + 1; Ii(ptr)=r1; Jj(ptr)=r1; Ss(ptr)=-vk/dy;
            if down_pos(k)>0, ptr=ptr+1; Ii(ptr)=r1; Jj(ptr)=down_pos(k); Ss(ptr)=vk/dy; end
        end

        % diagonal + coupling
        ptr=ptr+1; Ii(ptr)=r1; Jj(ptr)=r1; Ss(ptr)=alpha_x(k);
        ptr=ptr+1; Ii(ptr)=r1; Jj(ptr)=N+k; Ss(ptr)=mu_over_gx(k)*phi_psi;

        rhs(r1) = mu_over_gx(k)*vrx(k);

        % -------- zy row --------
        if uk >= 0
            ptr=ptr+1; Ii(ptr)=r2; Jj(ptr)=r2; Ss(ptr)=uk/dx;
            if left_pos(k)>0, ptr=ptr+1; Ii(ptr)=r2; Jj(ptr)=N+left_pos(k); Ss(ptr)=-uk/dx; end
        else
            ptr=ptr+1; Ii(ptr)=r2; Jj(ptr)=r2; Ss(ptr)=-uk/dx;
            if right_pos(k)>0, ptr=ptr+1; Ii(ptr)=r2; Jj(ptr)=N+right_pos(k); Ss(ptr)=uk/dx; end
        end

        if vk >= 0
            ptr=ptr+1; Ii(ptr)=r2; Jj(ptr)=r2; Ss(ptr)=vk/dy;
            if up_pos(k)>0, ptr=ptr+1; Ii(ptr)=r2; Jj(ptr)=N+up_pos(k); Ss(ptr)=-vk/dy; end
        else
            ptr=ptr+1; Ii(ptr)=r2; Jj(ptr)=r2; Ss(ptr)=-vk/dy;
            if down_pos(k)>0, ptr=ptr+1; Ii(ptr)=r2; Jj(ptr)=N+down_pos(k); Ss(ptr)=vk/dy; end
        end

        ptr=ptr+1; Ii(ptr)=r2; Jj(ptr)=r2; Ss(ptr)=alpha_y(k);
        ptr=ptr+1; Ii(ptr)=r2; Jj(ptr)=k; Ss(ptr)=-mu_over_gy(k)*phi_psi;

        rhs(r2) = mu_over_gy(k)*vry(k);
    end

    Ii = Ii(1:ptr); Jj = Jj(1:ptr); Ss = Ss(1:ptr);
    A = sparse(Ii, Jj, Ss, 2*N, 2*N);


    %% Identify inflow boundary nodes and enforce Dirichlet=0

    boundary_nodes = false(N,1);
    for k = 1:N
        if (Uc(k)>=0 && left_full(k)==0) || (Uc(k)<0 && right_full(k)==0) ...
                || (Vc(k)>=0 && up_full(k)==0) || (Vc(k)<0 && down_full(k)==0)
            boundary_nodes(k)=true;
        end
    end
    bn = find(boundary_nodes);
    for ii = 1:numel(bn)
        k = bn(ii);
        r1 = k; r2 = N+k;
        A(r1,:) = 0; A(r1,r1)=1; rhs(r1)=0;
        A(r2,:) = 0; A(r2,r2)=1; rhs(r2)=0;
    end


    %% Solve linear system

    Zall = A\rhs;
    zx = Zall(1:N);
    zy = Zall(N+1:end);


    %% Compute forces & moment

    % Bristle forces
    fx = sigma_0x*zx + sigma_1x*Vr*(-alpha_x.*zx + mu_over_gx.*vrx); % x-component
    fy = sigma_0y*zy + sigma_1y*Vr*(-alpha_y.*zy + mu_over_gy.*vry); % y-component

    % Map bristle deflection to full grid
    zx_full = zeros(Ny,Nx); zy_full = zeros(Ny,Nx);
    zx_full(idx) = zx; zy_full(idx) = zy;

    % Map bristle force to full grid
    fx_full = zeros(Ny,Nx); fy_full = zeros(Ny,Nx);
    fx_full(idx) = fx; fy_full(idx) = fy;

    switch lower(domainType)
        case 'rectangle'
            p = Fz/(4*a*b*beta(1/n_p, (2*n_p+1)/n_p))*(n_p+1)*(1 ...
                - (XX/a).^n_p - (YY/b).^n_p);
        case 'ellipse'
            p = 2*Fz/(pi*a*b)*(1 - (XX/a).^2 - (YY/b).^2);
    end
    p(~mask)=0;

    % Forces and moment
    Fx = sum(sum(fx_full.*p.*mask))*dx*dy;
    Fy = sum(sum(fy_full.*p.*mask))*dx*dy;
    Mz = sum(sum((-fx_full.*(YY + zy_full).*p + ...
        fy_full.*(XX + zx_full).*p).*mask))*dx*dy;


    %% Check convergence in forces/moment

    relF = norm([Fx-Fx_old; Fy-Fy_old; Mz-Mz_old]) / ...
        max(1e-12, norm([Fx_old;Fy_old;Mz_old]));
    if relF < tolF
        break;
    end
    Fx_old = Fx; Fy_old = Fy; Mz_old = Mz;


end

end