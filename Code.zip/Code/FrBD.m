clear
close all
clc;
set(0,'defaultTextInterpreter','latex');


%% Model parameters

% Input
v = 0.01; % Rigid relative velocity (m/s)

% Friction parameters
mu_s = 1;    % Static friction coefficient  (-)
mu_d = 0.7;  % Dynamic friction coefficient (-)
v_S = 0.01;  % Stribeck velocity            (m/s)
delta_S = 2; % Stribeck exponent            (-)
epsilon = 0; % Regularization parameter     (-)

% Rheological parameters
k_0 = 1e4;             % Zeroth-order micro-stiffness coefficient  (1/m)
k_i = [1e4; 1e4; 1e4]; % 1-n_th-order micro-stiffness coefficients (1/m)
tau_i = [1 0.1 0.01];  % Relaxation times                          (-)

% Auxiliary matrices
n = length(k_i);
Tau = diag(tau_i);
Tau_inv = inv(Tau);
I = ones(1,n);


%% Simulation

% Define simulation time 
t_stop = 0.04; % Simulation time (s)
delta_t = 1*10^(-6);
% sim('SingleTrackExpSim.slx',t_stop)
sim('SimulateFrBD.slx',t_stop)


%% Postprocessing

f = squeeze(ans.f);
z = squeeze(ans.z);
t = squeeze(ans.tout);


%% Figures

figure(1)
plot(t,f, 'LineWidth', 1)
xlabel('Time $t$ (s)');
ylabel('Nondimensional force $f$ (-)');
set(gca,'TickLabelInterpreter','latex')
